
Nama anggota kelompok :
1. Astuti  					(2014150099)
2. Rizkia Nisfi Maulidaan	(2015150112)


----------------------------------------------------------------
- Instal Laravel: `composer install --prefer-dist`
- Migrasikan database: `php artisan migrate`
- Ketikan Perintah: `php artisan db: seed`
- Lihat aplikasi di browser.
